<h1>{{$jurusan->nama}}</h1>
<h3>Kajur : {{$jurusan->kajur}}</h3>
<h3>Akreditasi : {{$jurusan->akreditasi}}</h3>