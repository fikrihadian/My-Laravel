<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="{{asset('css/materialize.min.css')}}" media="screen,projection"/>
</head>
<body>
<h1>Data Jurusan</h1>
	<table>
		<thead>
		<tr>
			<th>Nama</th>
			<th>Kajur</th>
			<th>Keterangan</th>
			<th>Akreditasi</th>
		</tr>
		</thead>
		@foreach($jurusan as $key)
		<tbody>
			<tr>
				<td>{{$key->nama}}</td>
				<td>{{$key->kajur}}</td>
				<td>{{$key->keterangan}}</td>
				<td>{{$key->akreditasi}}</td>
			</tr>
		</tbody>
		@endforeach
	</table>
</body>
</html>