@extends('layouts.app')

@section('title') CRUD Laravel - Data Jurusan @endsection

@section('content')

	<h1>Data Jurusan</h1>

	<a class="btn waves" href="{{route('tambah_jurusan')}}">Tambah Jurusan</a>
	<a class="btn waves" href="{{route('jurusan_pdf')}}">View All PDF</a>

	<table>
		<thead>
			<th>Nama</th>
			<th>Kajur</th>
			<th>Keterangan</th>
			<th>Akreditasi</th>
			<th>View PDF</th>
			<th>Download PDF</th>
		</thead>
		@foreach($jurusan as $key)
		<tbody>
			<tr>
				<td>{{$key->nama}}</td>
				<td>{{$key->kajur}}</td>
				<td>{{$key->keterangan}}</td>
				<td>{{$key->akreditasi}}</td>
				<td><a href="{{route('view_pdf',[$key->id])}}">View</a></td>
				<td><a href="{{route('download_pdf_jurusan',[$key->id])}}">Download</a></td>
				<td><a href="{{route('edit_jurusan',[$key->id])}}">Edit</a></td>
				<td><a onclick="return confirm('Hapus data{{$key->jurusan}}?')" href="{{route('delete_jurusan',[$key->id])}}">Delete</a></td>
			</tr>
		</tbody>
		@endforeach
	</table>

	{!!$jurusan->render()!!}

@endsection