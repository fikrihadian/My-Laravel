<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="{{asset('css/materialize.min.css')}}" media="screen,projection"/>
</head>
<body>
	<h1>Data Kelas</h1>
	
	<table>
		<thead>
		<tr>
			<th>Jurusan</th>
			<th>Kelas</th>
			<th>Jumlah Siswa</th>
			<th>Lokasi</th>
		</tr>
		</thead>
		@foreach($kelas as $key)
		<tbody>
			<tr>
				<td>{{$key->jurusan->nama}}</td>
				<td>{{$key->kelas}}</td>
				<td>{{$key->jumlah_siswa}}</td>
				<td>{{$key->lokasi}}</td>
			</tr>
		</tbody>
		@endforeach
	</table>


</body>
</html>