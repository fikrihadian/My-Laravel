<h1>{{$kelas->jurusan->nama}}</h1>
<h3>Kelas :{{$kelas->kelas}}</h3>
<h3>Jumlah Siswa : {{$kelas->jumlah_siswa}}</h3>
<h3>Lokasi : {{$kelas->lokasi}}</h3>