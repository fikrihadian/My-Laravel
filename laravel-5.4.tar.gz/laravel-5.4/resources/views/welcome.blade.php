@extends('layout.app')

@section('content')

    <div class="panel">
        <div id="area" style="height:800px;width:400px;border: 1px solid #2d89ef;">

        </div>
        <div class="panel">
            <div>
                <input type="text" name="nama" id="nama">
            </div>
            <div>
                <textarea id="pesan" rows="3" name="pesan"></textarea>
            </div>
            <div>
                <button id="kirim">Kirim</button>
            </div>
        </div>
    </div>

@endsection   

@section('footer')

<script type="text/javascript">
    var pusher = new Pusher('d6d44018ad7be7ad9165', {
        cluster: 'ap1'
    });
    var channel = pusher.subscribe('chat');
    channel.blind('receive', function(data) {
        var nama = data.nama;
        var pesan = data.pesan;
        var html_add = '<div><b>'+nama+'</b><br>'+pesan+'</div>';
        $("#area").append(html_add);
    });

    $("#kirim").on('click',function () {
        $.ajax({
            url:'{{route("kirim_pesan")}}',
            dataType:'json',
            type:'POST',
            data:{
                'nama':$("#nama").val(),
                'pesan':$("#pesan").val(),
                '_token':'{{csrf_token()}}'
            }
        
        })
    })
</script>

@endsection                 














