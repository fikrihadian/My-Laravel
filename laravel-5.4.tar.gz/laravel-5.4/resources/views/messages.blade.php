@extends('layouts.app')
@section('content')
<div class="row">
	<div class="col s3">
		<ul class="collection with-header">
			<li class="collection-header">
				<button class="btn">NEW</button>
			</li>
			<li class="collection-header">
				<h4>Inbox</h4>
			</li>

			@foreach($emails as $key)
			<li class="collection-item">
				<div>{{$key['from']}}<br>
				{{$key['date']}}<br>
				<b>{{$key['subject']}}</b>
				<a onclick="openMessage('{{$key['ids']}}')" class="secondary-content">
				<i class="material-icons">Send</i></a>
				</div>
			</li>
				@endforeach
		</ul>
	</div>

	<div class="col s9" id="messages">
		<div class="row">
			<div class="col s12">
				<div class="card">
					<div class="card-content">
						<span class="card-title">
						<b><span id="subject">Subject</span></b><br>
						<span id="from">From</span><br>
						<span id="date">Date</span><br>
						</span>
					<div id="msgbody">Messages</div>
					</div>
					<div class="card-action">
					<a href="#" class="btn">Reply</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
@endsection