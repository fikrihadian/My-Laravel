<?php $__env->startSection('title'); ?> CRUD Laravel - Tambah Jurusan <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Tambah Data Jurusan</h1>

<form method="POST" action="<?php echo e(route('save_jurusan')); ?>">
	<?php echo $__env->make('jurusan.forms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>