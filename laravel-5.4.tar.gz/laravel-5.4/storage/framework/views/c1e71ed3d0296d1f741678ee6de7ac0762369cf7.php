<?php echo e(csrf_field()); ?>

<div class="row">
	<div class="col s12">
		<div class="row">
			<div class="input-field col s12">
				<input type="text" name="kelas" value="<?php echo e(isset($kelas->kelas) ? $kelas->kelas : ''); ?>">
				<label>Kelas</label>
			</div>
			<div class="input-field col s6">
			<select name="id_jurusan">
				<?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if(isset($kelas->id_jurusan)): ?>
						<?php if($kelas->id_jurusan==$key->id): ?>
							<option selected value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
						<?php else: ?>
							<option value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
						<?php endif; ?>
					<?php else: ?>
						<option value="<?php echo e($key->id); ?>"><?php echo e($key->nama); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>					 
			</select>
				<label>Jurusan</label>
			</div>	
			<div class="input-field col s6">
			<input type="text" name="jumlah_siswa" value="<?php echo e(isset($kelas->jumlah_siswa) ? $kelas->jumlah_siswa : ''); ?>">
				<label>Jumlah Siswa</label>			
			</div>
			<div class="input-field col s12">
			<input type="text" name="lokasi" value="<?php echo e(isset($kelas->lokasi) ? $kelas->lokasi : ''); ?>">
				<label>Lokasi</label>
			</div>	
			<div>
				<button type="submit" name="simpan" class="btn waves-light waves-effect right">Simpan</button>
			</div>	
		</div>
	</div>
</div>		