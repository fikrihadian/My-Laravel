<?php $__env->startSection('title'); ?> CRUD Laravel - Edit Kelas <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Edit Data Kelas</h1>

<form method="POST" action="<?php echo e(route('update_kelas')); ?>">
	<input type="hidden" name="id" value="<?php echo e($kelas->id); ?>">
	<?php echo $__env->make('kelas.forms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<script type="text/javascript">
	$(document).ready(function() {
		$('select').material_select();
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>