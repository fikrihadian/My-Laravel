<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/materialize.min.css')); ?>" media="screen,projection"/>
</head>
<body>
	<h1>Data Kelas</h1>
	
	<table>
		<thead>
		<tr>
			<th>Jurusan</th>
			<th>Kelas</th>
			<th>Jumlah Siswa</th>
			<th>Lokasi</th>
		</tr>
		</thead>
		<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td><?php echo e($key->jurusan->nama); ?></td>
				<td><?php echo e($key->kelas); ?></td>
				<td><?php echo e($key->jumlah_siswa); ?></td>
				<td><?php echo e($key->lokasi); ?></td>
			</tr>
		</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>


</body>
</html>