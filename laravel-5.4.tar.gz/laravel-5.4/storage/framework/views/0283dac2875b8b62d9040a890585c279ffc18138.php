<?php echo e($nama); ?><br>
<?php echo e($alamat); ?><br>
Jurusan<ol type="1">
<?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<li><?php echo e($key); ?></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
</ol>