<h1><?php echo e($jurusan->nama); ?></h1>
<h3>Kajur : <?php echo e($jurusan->kajur); ?></h3>
<h3>Akreditasi : <?php echo e($jurusan->akreditasi); ?></h3>