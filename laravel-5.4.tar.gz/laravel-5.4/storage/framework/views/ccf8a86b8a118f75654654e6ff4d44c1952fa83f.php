<?php $__env->startSection('title'); ?> CRUD Laravel - Edit Jurusan <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<h1>Edit Data Jurusan</h1>

<form method="POST" action="<?php echo e(route('update_jurusan')); ?>">
	<input type="hidden" name="id" value="<?php echo e($jurusan->id); ?>">
	<?php echo $__env->make('jurusan.forms', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>