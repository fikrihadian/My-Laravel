<nav>
	<div class="nav-wrapper">
		<a href="#" class="brand-logo">logo</a>
		<ul id="nav-mobile" class="right hide-on-med-and-down">
			<li><a href="<?php echo e(url('/home')); ?>">Home</a></li>
			<li><a href="<?php echo e(url('/kelas')); ?>">Data Kelas</a></li>
			<li><a href="<?php echo e(url('/jurusan')); ?>">Data Jurusan</a></li>

			<?php if(!Auth::check()): ?>
				<li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
			<?php else: ?>
				<li><a href="<?php echo e(route('logout')); ?>"
					onclick="event.preventDefault();
							document.getElementById('logout-form').submit();">
					Logout
				</a></li>

				<form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display:none;">
					<?php echo e(csrf_field()); ?>

				</form>
			<?php endif; ?>

		</ul>
	</div>
</nav> 