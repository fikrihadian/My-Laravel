<?php echo e(csrf_field()); ?>

<div class="row">
	<div class="col s12">
		<div class="row">
			<div class="input-field col s12">
				<input type="text" name="nama" value="<?php echo e(isset($jurusan->nama) ? $jurusan->nama : ''); ?>">
				<label>Nama</label>
			</div>
			<div class="input-field col s6">
			<input type="text" name="kajur" value="<?php echo e(isset($jurusan->kajur) ? $jurusan->kajur : ''); ?>">
				<label>Kajur</label>
			</div>	
			<div class="input-field col s6">
			<input type="text" name="keterangan" value="<?php echo e(isset($jurusan->keterangan) ? $jurusan->keterangan : ''); ?>">
				<label>Keterangan</label>			
			</div>
			<div class="input-field col s12">
			<input type="text" name="akreditasi" value="<?php echo e(isset($jurusan->akreditasi) ? $jurusan->akreditasi : ''); ?>">
				<label>Akreditas</label>
			</div>	
			<div>
				<button type="submit" name="simpan" class="btn waves-light waves-effect right">Simpan</button>
			</div>	
		</div>
	</div>
</div>		