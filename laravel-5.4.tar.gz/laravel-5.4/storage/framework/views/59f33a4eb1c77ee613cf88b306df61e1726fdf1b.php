<?php $__env->startSection('title'); ?> CRUD Laravel - Data Jurusan <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<h1>Data Jurusan</h1>

	<a class="btn waves" href="<?php echo e(route('tambah_jurusan')); ?>">Tambah Jurusan</a>
	<a class="btn waves" href="<?php echo e(route('jurusan_pdf')); ?>">View All PDF</a>

	<table>
		<thead>
			<th>Nama</th>
			<th>Kajur</th>
			<th>Keterangan</th>
			<th>Akreditasi</th>
			<th>View PDF</th>
			<th>Download PDF</th>
		</thead>
		<?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td><?php echo e($key->nama); ?></td>
				<td><?php echo e($key->kajur); ?></td>
				<td><?php echo e($key->keterangan); ?></td>
				<td><?php echo e($key->akreditasi); ?></td>
				<td><a href="<?php echo e(route('view_pdf',[$key->id])); ?>">View</a></td>
				<td><a href="<?php echo e(route('download_pdf_jurusan',[$key->id])); ?>">Download</a></td>
				<td><a href="<?php echo e(route('edit_jurusan',[$key->id])); ?>">Edit</a></td>
				<td><a onclick="return confirm('Hapus data<?php echo e($key->jurusan); ?>?')" href="<?php echo e(route('delete_jurusan',[$key->id])); ?>">Delete</a></td>
			</tr>
		</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<?php echo $jurusan->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>