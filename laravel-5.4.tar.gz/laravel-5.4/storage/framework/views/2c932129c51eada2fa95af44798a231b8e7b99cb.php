<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/materialize.min.css')); ?>" media="screen,projection"/>
</head>
<body>
<h1>Data Jurusan</h1>
	<table>
		<thead>
		<tr>
			<th>Nama</th>
			<th>Kajur</th>
			<th>Keterangan</th>
			<th>Akreditasi</th>
		</tr>
		</thead>
		<?php $__currentLoopData = $jurusan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td><?php echo e($key->nama); ?></td>
				<td><?php echo e($key->kajur); ?></td>
				<td><?php echo e($key->keterangan); ?></td>
				<td><?php echo e($key->akreditasi); ?></td>
			</tr>
		</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>