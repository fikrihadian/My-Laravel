<?php $__env->startSection('title'); ?> CRUD Laravel - Data Kelas <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

	<h1>Data Kelas</h1>

	<a class="btn waves" href="<?php echo e(route('tambah_kelas')); ?>">Tambah Kelas</a>
	<a class="btn waves" href="<?php echo e(route('kelas_pdf')); ?>">View All PDF</a>

	<table>
		<thead>
			<th>Jurusan</th>
			<th>Kelas</th>
			<th>Jumlah Siswa</th>
			<th>Lokasi</th>
			<th>Edit</th>
			<th>Delete</th>
			<th>PDF</th>
		</thead>
		<?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tbody>
			<tr>
				<td><?php echo e($key->jurusan->nama); ?></td>
				<td><?php echo e($key->kelas); ?></td>
				<td><?php echo e($key->jumlah_siswa); ?></td>
				<td><?php echo e($key->lokasi); ?></td>
				<td><a href="<?php echo e(route('edit_kelas',[$key->id])); ?>">Edit</a></td>
				<td><a onclick="return confirm('Hapus data<?php echo e($key->kelas); ?>?')" href="<?php echo e(route('delete_kelas',[$key->id])); ?>">Delete</a></td>
				<td><a href="<?php echo e(route('pdf_kelas',[$key->id])); ?>">View</a></td>
				<td><a href="<?php echo e(route('download_pdf_kelas',[$key->id])); ?>">Download</a></td>
			</tr>
		</tbody>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<?php echo $kelas->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>