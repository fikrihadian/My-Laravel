<h1><?php echo e($kelas->jurusan->nama); ?></h1>
<h3>Kelas :<?php echo e($kelas->kelas); ?></h3>
<h3>Jumlah Siswa : <?php echo e($kelas->jumlah_siswa); ?></h3>
<h3>Lokasi : <?php echo e($kelas->lokasi); ?></h3>